async function fetchCatBreeds() {
    const response = await fetch('https://api.thecatapi.com/v1/breeds');
    const data = await response.json();
    const breeds = data.slice(0, 10); // Pegando apenas 10 raças
    displayBreeds(breeds);
}

// Função para exibir a lista de raças no DOM
function displayBreeds(breeds) {
    const breedList = document.getElementById('breed-list');
    breedList.innerHTML = ''; // Limpa a lista antes de exibir os dados
    breeds.forEach(breed => {
        const listItem = document.createElement('li');
        listItem.textContent = breed.name;
        listItem.setAttribute('data-id', breed.id);
        breedList.appendChild(listItem);
    });
    addClickEvent(); // Adiciona o evento de clique após renderizar
}

// Função para filtrar a lista de raças com base no input do usuário
function filterBreeds(event) {
    const searchTerm = event.target.value.toLowerCase();
    const breeds = document.querySelectorAll('#breed-list li');
    
    breeds.forEach(breed => {
        if (breed.textContent.toLowerCase().includes(searchTerm)) {
            breed.style.display = ''; // Exibe o item
        } else {
            breed.style.display = 'none'; // Esconde o item
        }
    });
}

// Função para salvar raça favorita no localStorage
function saveFavorite(breed) {
    let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
    if (!favorites.includes(breed)) {
        favorites.push(breed);
        localStorage.setItem('favorites', JSON.stringify(favorites));
        alert(`${breed} foi adicionado aos favoritos!`);
        loadFavorites();
    }
}

// Carregar favoritos ao recarregar a página
function loadFavorites() {
    const favorites = JSON.parse(localStorage.getItem('favorites')) || [];
    const favoritesList = document.getElementById('favorites-list');
    favoritesList.innerHTML = ''; // Limpa a lista

    favorites.forEach(favorite => {
        const listItem = document.createElement('li');
        listItem.textContent = favorite;
        favoritesList.appendChild(listItem);
    });
}

// Função para buscar detalhes de uma raça específica
async function fetchBreedDetails(id) {
    const response = await fetch(`https://api.thecatapi.com/v1/breeds/${id}`);
    const breed = await response.json();
    showBreedDetails(breed);
}

// Função para exibir detalhes sobre a raça
function showBreedDetails(breed) {
    const detailsDiv = document.getElementById('breed-details');
    detailsDiv.innerHTML = `
        <h3>${breed.name}</h3>
        <p>Temperamento: ${breed.temperament}</p>
        <p>Origem: ${breed.origin}</p>
        <p>Descrição: ${breed.description}</p>
        <img src="${breed.image?.url}" alt="${breed.name}" style="width: 200px; height: auto;">
    `;
}

// Função para adicionar evento de clique a cada raça
function addClickEvent() {
    const breeds = document.querySelectorAll('#breed-list li');
    breeds.forEach(breed => {
        breed.addEventListener('click', () => {
            const id = breed.getAttribute('data-id');
            const name = breed.textContent;
            saveFavorite(name);
            fetchBreedDetails(id);
        });
    });
}

// Adiciona o evento de escuta ao input de filtro
document.getElementById('breed-filter').addEventListener('input', filterBreeds);

// Chama as funções quando os dados são carregados
fetchCatBreeds();
loadFavorites();